define({
	"button.switch-metaview.tooltip": "Zwischen Metaansicht und normaler Ansicht umschalten"
});
