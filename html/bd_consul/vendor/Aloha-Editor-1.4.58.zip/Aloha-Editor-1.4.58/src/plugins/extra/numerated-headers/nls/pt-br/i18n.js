define({
	"headerids.label.target": "Alvo",
	"headerids.button.reset": "Resetar",
	"headerids.button.set": "Colocar"
});
