define({
	"floatingmenu.tab.file": "Датотека"
});
