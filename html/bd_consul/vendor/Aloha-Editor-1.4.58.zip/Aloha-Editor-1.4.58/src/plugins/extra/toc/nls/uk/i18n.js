define({
	"button.addtoc.tooltip": "Зміст"
});
