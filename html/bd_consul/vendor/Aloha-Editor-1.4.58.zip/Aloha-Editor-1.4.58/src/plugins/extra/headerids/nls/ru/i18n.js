define({
	"headerids.label.target": "Цель",
	"headerids.button.reset": "Сбросить",
	"headerids.button.set": "Установить",
	"internal_hyperlink": "Внутренняя гиперссылка"
});
