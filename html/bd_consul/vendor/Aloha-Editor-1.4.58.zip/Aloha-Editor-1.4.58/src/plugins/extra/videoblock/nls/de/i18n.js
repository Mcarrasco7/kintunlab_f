define({
	"tab.video.label": "Video",
	"button.removevideo.tooltip": "Video entfernen"
});
