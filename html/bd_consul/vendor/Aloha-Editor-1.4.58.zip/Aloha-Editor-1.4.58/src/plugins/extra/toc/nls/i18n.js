define({
	"root":  {
		"button.addtoc.tooltip": "Table of contents"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});
