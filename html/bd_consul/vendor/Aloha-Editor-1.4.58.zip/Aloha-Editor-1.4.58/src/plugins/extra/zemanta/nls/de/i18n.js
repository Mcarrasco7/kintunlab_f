define({
	"floatingmenu.tab.related": "Ähnlich",
	"button.zemanta.tooltip": "Zemanta",
	"zemanta.message.shorttext": "Um ähnliche Artikel, Bilder oder Tags vorzuschlagen benötigt das Zemanta Service mindestens 140 Zeichen."
});
