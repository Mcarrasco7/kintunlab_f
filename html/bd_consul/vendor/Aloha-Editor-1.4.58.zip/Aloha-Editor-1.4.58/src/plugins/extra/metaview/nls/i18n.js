define({
	"root":  {
		"button.switch-metaview.tooltip": "Switch between meta and normal view"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});
