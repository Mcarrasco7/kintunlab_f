define({
	"root":  {
		"button.addlink.tooltip": "Insert Link",
		"button.removelink.tooltip": "Remove Link",
		"newlink.defaulttext": "New Link",
		"floatingmenu.tab.link": "Link"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});
