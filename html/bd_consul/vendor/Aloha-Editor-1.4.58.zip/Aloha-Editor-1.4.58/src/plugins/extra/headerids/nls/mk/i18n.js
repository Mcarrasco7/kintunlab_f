define({
	"headerids.label.target": "Мета",
	"headerids.button.reset": "Ресетирај",
	"headerids.button.set": "Постави",
	"internal_hyperlink": "Внатрешен линк"
});
