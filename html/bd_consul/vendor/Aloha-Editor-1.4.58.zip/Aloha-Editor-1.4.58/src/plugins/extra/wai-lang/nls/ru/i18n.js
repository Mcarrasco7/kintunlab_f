define({
	"floatingmenu.tab.wai-lang": "Языковая аннотация",
	"button.add-wai-lang-remove.tooltip": "Удалить языковую аннотацию",
	"button.add-wai-lang.tooltip": "Добавить языковую аннотацию"
});
