define({
	'change-textcolor-color': 'Textfarbe ändern',
	'remove-textcolor-color': 'Textfarbe entfernen',
	'change-textcolor-background-color': 'Texthintergrund ändern',
	'remove-textcolor-background-color': 'Texthintergrund entfernen'
});
