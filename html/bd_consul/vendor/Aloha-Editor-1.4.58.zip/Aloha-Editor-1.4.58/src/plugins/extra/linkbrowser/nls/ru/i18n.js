define({
	"button.addlink.tooltip": "Вставить ссылку",
	"button.removelink.tooltip": "Удалить ссылку",
	"newlink.defaulttext": "Новая ссылка",
	"floatingmenu.tab.link": "Ссылка"
});
