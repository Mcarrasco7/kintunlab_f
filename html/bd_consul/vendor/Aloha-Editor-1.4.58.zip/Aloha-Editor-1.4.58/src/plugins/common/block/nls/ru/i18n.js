define({
	"button.toggledragdrop.tooltip": "Переключатель Drag & Drop"
});
