define({
	"button.createulist.tooltip": "Вставить Список",
	"button.createolist.tooltip": "Вставить Упорядоченный Список",
	"button.indentlist.tooltip": "Список с отступом",
	"button.outdentlist.tooltip": "Список с наступом",
	"floatingmenu.tab.list": "Списки"
});
