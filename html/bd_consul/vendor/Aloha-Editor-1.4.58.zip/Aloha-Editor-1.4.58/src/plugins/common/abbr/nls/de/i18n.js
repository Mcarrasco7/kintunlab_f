define({
	"floatingmenu.tab.abbr": "Abkürzung",
	"button.addabbr.tooltip": "Abkürzung einfügen",
	"button.remabbr.tooltip": "Abkürzung entfernen",
	"button.abbr.tooltip": "Als Abkürzung formatieren",
	"newabbr.defaulttext": "Abb"
});
