define({
	"button.addhr.tooltip": "Horizontale Linie einfügen"
});
