define({
	"button.createulist.tooltip": "Unsortierte Liste einfügen",
	"button.createolist.tooltip": "Sortierte Liste einfügen",
	"button.createdlist.tooltip": "Definitionen-Liste einfügen",
	"button.indentlist.tooltip": "Einzug vergrößern",
	"button.outdentlist.tooltip": "Einzug verkleinern",
	"floatingmenu.tab.list": "Listen"
});
