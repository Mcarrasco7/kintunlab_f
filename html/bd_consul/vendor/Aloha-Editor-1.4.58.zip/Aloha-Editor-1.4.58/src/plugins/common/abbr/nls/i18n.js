define({
	"root":  {
		"floatingmenu.tab.abbr": "Abbreviation",
		"button.addabbr.tooltip": "insert abbreviation",
		"button.remabbr.tooltip": "remove abbreviation",
		"button.abbr.tooltip": "format as abbreviation",
		"newabbr.defaulttext": "Abbr"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});
