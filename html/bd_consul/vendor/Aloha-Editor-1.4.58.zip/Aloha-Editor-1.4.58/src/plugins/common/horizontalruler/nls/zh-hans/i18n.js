define({
	"button.addhr.tooltip": "添加一个水平标尺"
});
