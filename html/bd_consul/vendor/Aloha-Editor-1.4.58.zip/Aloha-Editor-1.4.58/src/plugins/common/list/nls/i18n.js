define({
	"root":  {
		"button.createulist.tooltip": "Insert Unordered List",
		"button.createolist.tooltip": "Insert Ordered List",
		"button.createdlist.tooltip": "Insert Definition List",
		"button.indentlist.tooltip": "Increase Indent",
		"button.outdentlist.tooltip": "Decrease Indent",
		"floatingmenu.tab.list": "Lists"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});
