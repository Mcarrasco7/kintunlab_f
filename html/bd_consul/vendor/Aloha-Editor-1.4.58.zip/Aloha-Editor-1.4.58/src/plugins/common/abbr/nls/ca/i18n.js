define({
	"floatingmenu.tab.abbr": "Abreviació",
	"button.addabbr.tooltip": "Introdueix una abreviació",
	"button.abbr.tooltip": "Formata com una abreviació",
	"newabbr.defaulttext": "Abrev"
});
