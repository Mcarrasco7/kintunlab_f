define({
	"button.addcharacter.tooltip": "выбрать спецсимвол"
});
