define({
	"root":  {
		"button.toggledragdrop.tooltip": "Toggle Drag & Drop"
	},
		"ca": true,
		"de": true,
		"mk": true,
		"pt-br": true,
		"ru": true,
		"uk": true,
		"zh-hans": true
});
