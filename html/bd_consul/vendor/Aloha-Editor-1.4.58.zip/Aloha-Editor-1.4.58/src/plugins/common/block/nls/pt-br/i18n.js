define({
	"button.toggledragdrop.tooltip": "Alternar Drag & Drop"
});
