define({
	"floatingmenu.tab.abbr": "Abreviação",
	"button.addabbr.tooltip": "inserir abreviação",
	"button.abbr.tooltip": "formatar como abreviação",
	"newabbr.defaulttext": "Abreviação"
});
